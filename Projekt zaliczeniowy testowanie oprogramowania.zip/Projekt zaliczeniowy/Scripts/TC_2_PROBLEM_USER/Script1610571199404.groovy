import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

// COMPLETE CHECKOUT NEGATIVE

// open browser

WebUI.openBrowser("https://www.saucedemo.com/")

// verify login page
WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/LoginPage/input_standard_userlocked_out_userproblem_userperformance_glitch_user_login-button'), 1)

// enter credentials
WebUI.setText(findTestObject('Page_Swag Labs/LoginPage/input_standard_userlocked_out_userproblem_userperformance_glitch_user_user-name'), findTestData("User_Data").getValue(1, rowNo))
WebUI.setText(findTestObject('Page_Swag Labs/LoginPage/input_standard_userlocked_out_userproblem_userperformance_glitch_user_password'), findTestData("User_Data").getValue(2, rowNo))

// verify login
WebUI.verifyElementAttributeValue(findTestObject('Page_Swag Labs/LoginPage/input_standard_userlocked_out_userproblem_userperformance_glitch_user_user-name'), "value", findTestData("User_Data").getValue(1, rowNo), 1)

// submit login
WebUI.click(findTestObject('Page_Swag Labs/LoginPage/input_standard_userlocked_out_userproblem_userperformance_glitch_user_login-button'))

// verify home page
WebUI.verifyElementPresent(findTestObject('Page_Swag Labs/HomePage/div_Open Menu_app_logo'), 1)

// add product to the cart
WebUI.click(findTestObject('Object Repository/Page_Swag Labs/HomePage/button_ADD TO CART'))

// open cart
WebUI.click(findTestObject('Object Repository/Page_Swag Labs/HomePage/Cart'))

// verify open cart
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Swag Labs/CartPage/div_Your Cart'), 1)

// go to checkout page
WebUI.click(findTestObject('Object Repository/Page_Swag Labs/CartPage/a_CHECKOUT'))

// verify checkout page
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/div_Checkout Your Information'), 1)

// enter personal information
WebUI.setText(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_Checkout Your Information_first-name'), findTestData("User_Data").getValue(3, rowNo))
WebUI.setText(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_Checkout Your Information_last-name'), findTestData("User_Data").getValue(4, rowNo))
WebUI.setText(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_Checkout Your Information_postal-code'), findTestData("User_Data").getValue(5, rowNo))

// verify entered information
WebUI.verifyElementAttributeValue(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_Checkout Your Information_first-name'),"value", findTestData("User_Data").getValue(3, rowNo), 1)
WebUI.verifyElementAttributeValue(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_Checkout Your Information_last-name'), "value", findTestData("User_Data").getValue(4, rowNo), 1)
WebUI.verifyElementAttributeValue(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_Checkout Your Information_postal-code'),"value",  findTestData("User_Data").getValue(5, rowNo), 1)

// submit checkout (checkout overview page should open)
WebUI.click(findTestObject('Object Repository/Page_Swag Labs/CheckoutPage/input_CANCEL_btn_primary cart_button'))

// verify checkout overview page
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Swag Labs/CheckoutOverviewPage/div_Checkout Overview'), 1)

// finish checkout
WebUI.click(findTestObject('Object Repository/Page_Swag Labs/CheckoutOverviewPage/a_FINISH'))

// verify complete checkout
WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Swag Labs/FinishPage/div_Finish'), 1)


// close browser
WebUI.closeBrowser()

